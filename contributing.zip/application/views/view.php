<!DOCTYPE html>
<html dir="ltr"> 

    <?php if($page=='home'){ ?>
        <h1>Hi</h1><div>I'm in the homepage</div>
    <?php }elseif ($page=='folder1') { ?>
       <h1>Hi</h1><div>I'm in folder1</div>
    <?php }elseif ($page=='folder2') { ?>
        <h1>Hi</h1><div>I'm in folder2</div>
    <?php  } ?>  

</html>